Changelog
=========

[1.31.1] - 2026-05-13
--------------------

### Bug Fixes

- fix: check for corosync-qdevice service in bad state before stopping (#385)

[1.31.0] - 2026-05-07
--------------------

### New Features

- feat: export node attributes utilization (#382)
- feat: Parametrize no_log usage in ha_cluster role (#383)

### Other Changes

- refactor: Restructure task files to enable more differences between shells (#378)
- ci: bump actions/github-script from 8 to 9 (#381)

[1.30.0] - 2026-04-28
--------------------

### New Features

- feat: crmsh - Add support for QDevice, Qnet and Diskless SBD (#374)
- feat: add role fingerprints to syslog (#375)
- feat: export stonith levels (#376)

### Other Changes

- ci: bump actions/upload-artifact from 6 to 7 (#360)
- ci: address issues with tmt-* files [citest_skip] (#361)
- test: ensure role gathers the facts it uses by having test clear_facts before include_role (#363)
- ci: tox-lsr 3.17.0 - container test improvements, use ansible 2.20 for fedora 43 [citest_skip] (#364)
- ci: tox-lsr 3.17.1 - previous update broke container tests, this fixes them [citest_skip] (#365)
- ci: update test composes [citest_skip] (#366)
- ci: fix yum repos to use devel site instead of old site name [citest_skip] (#367)
- ci: use codecov @v6 [citest_skip] (#368)
- ci: update header for run_role_with_clear_facts [citest_skip] (#369)
- test: support ansible-test milestone version 2.22 [citest_skip] (#370)
- ci: Comply with Ansible partner certification checking [citest_skip] (#371)
- ci: ansible-lint requires dependencies to be installed [citest_skip] (#372)
- ci: fix ci scripts [citest_skip] (#379)

[1.29.1] - 2026-02-18
--------------------

### Bug Fixes

- fix: ostree - add dnf/dnf5 package, add firewall packages (#358)

### Other Changes

- ci: update pcs test matrix (#349)
- ci: bump ansible/ansible-lint from 25 to 26 (#350)
- ci: skip most CI checks if title contains citest skip [citest_skip] (#351)
- ci: ansible-lint - remove .collection directory from converted collection [citest_skip] (#352)
- ci: tox-lsr version 3.15.0 [citest_skip] (#353)
- ci: Add Fedora 43, remove Fedora 41 from Testing Farm CI (#354)
- ci: update for the latest linters and tmt (#355)
- ci: Ansible version must be string, not float [citest_skip] (#356)

[1.29.0] - 2026-01-17
--------------------

### New Features

- feat: Support this role in container builds (#341)

### Other Changes

- ci: fix container bootc test on el9 (#344)
- ci: move sitepackages to python unit test workflow (#347)

[1.28.1] - 2026-01-13
--------------------

### Other Changes

- ci: bump actions/upload-artifact from 5 to 6 (#340)
- refactor: handle INJECT_FACTS_AS_VARS=false by using ansible_facts instead (#342)

[1.28.0] - 2025-12-17
--------------------

### New Features

- feat: add support for fencing-watchdog-timeout (#335)

### Other Changes

- ci: define job tag by a gitlab variable (#333)
- ci: introduce ansible-test ignore file for version 2.20 (#334)
- ci: bump gha checkout from v5 to v6 (#336)
- ci: add qemu tests for Fedora 43, drop Fedora 41 (#337)
- ci: update test composes (#338)

[1.27.1] - 2025-11-17
--------------------

### Bug Fixes

- fix: cannot use community-general version 12 - no py27 and py36 support (#330)

### Other Changes

- test: fix ansible-test import 3.5 issues on ansible-core 2.14 (#331)

[1.27.0] - 2025-11-13
--------------------

### New Features

- feat: export cluster constraints (#326)

### Other Changes

- ci: bump github/codeql-action from 3 to 4 (#323)
- ci: bump actions/upload-artifact from 4 to 5 (#324)
- ci: use versioned upload-artifact instead of master; bump codeql-action to v4; bump upload-artifact to v5 (#325)
- ci: bump tox-lsr to 3.13.0 (#327)
- ci: bump tox-lsr to 3.14.0 - this moves standard-inventory-qcow2 to tox-lsr (#328)

[1.26.0] - 2025-10-21
--------------------

### New Features

- feat: export cluster properties and resource defaults and resource operation defaults (#318)

### Other Changes

- style: allow a long line in fixture_psks.yml (#308)
- ci: run ansible-lint after converting the role to a collection (#309)
- ci: bump actions/checkout from 4 to 5 (#310)
- ci: rollout several recent changes to CI testing (#312)
- ci: support openSUSE Leap in qemu/kvm test matrix (#313)
- ci: use the new epel feature to enable EPEL for testing farm (#314)
- ci: use tox-lsr 3.12.0 for osbuild_config.yml feature (#316)
- ci: use JSON format for __bootc_validation (#317)
- ci: bump actions/github-script from 7 to 8 (#319)
- refactor: remove unused pcs_provider variable (#320)
- ci: add tmt plans and tests for running from gitlab-ci (#321)

[1.25.6] - 2025-08-20
--------------------

### Other Changes

- test: fix setting and resetting PQC (#306)

[1.25.5] - 2025-08-18
--------------------

### Other Changes

- test: clean up certs/keys created by tests (#304)

[1.25.4] - 2025-08-08
--------------------

### Other Changes

- refactor: crmsh update for ansible-core 2.19 (#301)
- style: fix typos (#302)

[1.25.3] - 2025-08-01
--------------------

### Bug Fixes

- fix: crsmh corosync template wrongly used variable from run_once host (#299)

### Other Changes

- test: use post quantum crypto for certs where available (#297)
- test: don't use fence_xvm in tests (#298)

[1.25.2] - 2025-07-24
--------------------

### Bug Fixes

- fix: use empty init to prevent old ansible issues (#294)

### Other Changes

- ci: add some ansible-test ignores for 2.14 (#293)
- ci: update pcs test matrix (#295)

[1.25.1] - 2025-07-15
--------------------

### Other Changes

- refactor: fixes for ansible 2.19 (#291)

[1.25.0] - 2025-07-09
--------------------

### New Features

- feat: export cluster resources (#288)

### Other Changes

- ci: use py311 for pylint (#289)

[1.24.1] - 2025-07-02
--------------------

### Bug Fixes

- fix: ensure /var/lib/pcsd exists (#285)

### Other Changes

- refactor: support Ansible 2.19 (#286)

[1.24.0] - 2025-06-23
--------------------

### New Features

- feat: crmsh SLES 16 changes and introduction of zypper patterns (#283)

### Other Changes

- ci: Add Fedora 42; use tox-lsr 3.9.0; use lsr-report-errors for qemu tests (#280)
- ci: Add support for bootc end-to-end validation tests (#281)
- ci: Use ansible 2.19 for fedora 42 testing; support python 3.13 (#282)

[1.23.2] - 2025-05-15
--------------------

### Other Changes

- ci: bump tox-lsr to 3.8.0; rename qemu/kvm tests (#277)
- test: update attributes and utilization tests for new pcs (#278)

[1.23.1] - 2025-05-05
--------------------

### Other Changes

- ci: bump sclorg/testing-farm-as-github-action from 3 to 4 (#274)
- refactor: use single line pylint disable broad-except (#275)

[1.23.0] - 2025-04-23
--------------------

### New Features

- feat: export pcsd and OS configuration (#264)
- feat: crmsh remove python3-rpm dependency (#270)

### Bug Fixes

- fix: restart qdevice when its certificates have been regenerated (#262)
- fix: disable proxy when connecting to pcsd local socket (#265)

### Other Changes

- ci: update pcs test matrix (#253)
- ci: ansible-plugin-scan is disabled for now (#256)
- ci: bump ansible-lint to v25; provide collection requirements for ansible-lint (#259)
- refactor: fix python black formatting (#260)
- ci: Check spelling with codespell (#261)
- ci: Add test plan that runs CI tests and customize it for each role (#263)
- ci: In test plans, prefix all relate variables with SR_ (#266)
- ci: Fix bug with ARTIFACTS_URL after prefixing with SR_ (#267)
- ci: several changes related to new qemu test, ansible-lint, python versions, ubuntu versions (#268)
- test: update alerts test for new pcs (#269)
- ci: use tox-lsr 3.6.0; improve qemu test logging (#271)
- ci: skip storage scsi, nvme tests in github qemu ci (#272)

[1.22.2] - 2025-01-27
--------------------

### Bug Fixes

- fix: update for EL10 (#254)

[1.22.1] - 2025-01-09
--------------------

### Other Changes

- style: fix ansible-lint issues introduced in 7771830 (#251)

[1.22.0] - 2024-12-13
--------------------

### New Features

- feat: Remove python expect dependency in crmsh (#249)

[1.21.1] - 2024-12-09
--------------------

### Bug Fixes

- fix: update constraints commands syntax for pcs-0.12 (#245)

[1.21.0] - 2024-12-09
--------------------

### New Features

- feat: export corosync configuration (#231)

### Bug Fixes

- fix: list cloud agent packages by architecture (#244)

### Other Changes

- ci: tests update for pcs-0.12 and pacemaker-3 (#238)
- ci: bump codecov/codecov-action from 4 to 5 (#239)
- ci: Use Fedora 41, drop Fedora 39 (#242)
- ci: Use Fedora 41, drop Fedora 39 - part two (#243)

[1.20.0] - 2024-10-30
--------------------

### New Features

- feat: crmsh 4.6.0 support and stonith-enabled workflow update (#232)

### Other Changes

- ci: Add tags to TF workflow, allow more [citest bad] formats (#229)
- docs: improve comments in SBD examples (#230)
- ci: ansible-test action now requires ansible-core version (#233)
- ci: add YAML header to github action workflow files (#234)
- refactor: Use vars/RedHat_N.yml symlink for CentOS, Rocky, Alma wherever possible (#236)

[1.19.2] - 2024-08-21
--------------------

### Bug Fixes

- fix: openssl is now required for password (#227)

[1.19.1] - 2024-08-20
--------------------

### Bug Fixes

- fix: Fixes for new pcs and ansible (#223)

### Other Changes

- ci: Add workflow for ci_test bad, use remote fmf plan (#221)
- ci: Fix missing slash in ARTIFACTS_URL (#222)
- docs: fix sbd_devices documentation and examples (#224)
- test: add gather_facts true for tests that need facts (#225)

[1.19.0] - 2024-08-01
--------------------

### New Features

- feat: crmsh watchdog correction, remove obsolete assert for softdog (#217)
- feat: Add alerts support (#218)

### Other Changes

- ci: Add tft plan and workflow (#214)
- ci: Update fmf plan to add a separate job to prepare managed nodes (#216)
- ci: bump sclorg/testing-farm-as-github-action from 2 to 3 (#219)

[1.18.0] - 2024-07-02
--------------------

### New Features

- feat: crmsh corosync jinja2 template rework (#212)

### Other Changes

- ci: ansible-lint action now requires absolute directory (#211)

[1.17.1] - 2024-06-11
--------------------

### Other Changes

- ci: use tox-lsr 3.3.0 which uses ansible-test 2.17 (#205)
- ci: tox-lsr 3.4.0 - fix py27 tests; move other checks to py310 (#207)
- ci: fix Python discovery with Ansible 2.17+ (#208)
- ci: Add supported_ansible_also to .ansible-lint (#209)

[1.17.0] - 2024-04-22
--------------------

### New Features

- feat: crmsh enhancements, master slave, validations (#197)
- feat: Add support for utilization (#202)

### Bug Fixes

- fix: make consistent approach for multiple node attributes sets (#201)

### Other Changes

- ci: fix internal gitlab CI (#200)

[1.16.0] - 2024-04-04
--------------------

### New Features

- feat: SLES15 enablement, HAE detection (#192)
- feat: Add support for ACL (#193)
- feat: easily install cloud agents (#194)
- feat: ha_cluster_node_options allows per-node addresses and SBD options to be set (#196)

### Other Changes

- ci: bump ansible/ansible-lint from 6 to 24 (#195)
- ci: bump mathieudutour/github-tag-action from 6.1 to 6.2 (#198)

[1.15.0] - 2024-02-13
--------------------

### New Features

- feat: crmsh workflow and SUSE support (#186)

### Other Changes

- docs: change Supported to Compatible (#188)

[1.14.0] - 2024-02-07
--------------------

### New Features

- feat: add support for configuring node attributes (#184)

### Other Changes

- ci: bump codecov/codecov-action from 3 to 4 (#182)
- ci: fix python unit test - copy pytest config to tests/unit (#183)

[1.13.5] - 2024-01-16
--------------------

### Other Changes

- ci: bump github/codeql-action from 2 to 3 (#176)
- ci: Use supported ansible-lint action; run ansible-lint against the collection (#177)
- ci: Use supported ansible-lint action; run ansible-lint against the collection (#178)
- style: followup for recent ansible-lint related changes (#179)

[1.13.4] - 2023-12-12
--------------------

### Other Changes

- test: fix jinja templates in conditionals (#173)

[1.13.3] - 2023-12-08
--------------------

### Other Changes

- refactor: get_ostree_data.sh use env shebang - remove from .sanity* (#171)

[1.13.2] - 2023-12-05
--------------------

### Bug Fixes

- fix: set sbd.service timeout based on SBD_START_DELAY (#169)

### Other Changes

- ci: bump actions/github-script from 6 to 7 (#168)

[1.13.1] - 2023-12-01
--------------------

### Bug Fixes

- fix: manage firewall on qnetd hosts (#166)

[1.13.0] - 2023-11-29
--------------------

### New Features

- feat: support for ostree systems (#159)

### Other Changes

- test: update for ansible-test-2.16 (#162)
- test: do not use true test with select (#163)

[1.12.0] - 2023-11-06
--------------------

### New Features

- feat: add an option to enable Resilient Storage rpm repository (#158)

### Bug Fixes

- fix: cast sbd option value to string (#160)

[1.11.0] - 2023-10-23
--------------------

### New Features

- feat: Add support for configuring stonith levels (#147)

### Other Changes

- build(deps): bump actions/checkout from 3 to 4 (#146)
- ci: dependabot git commit msg lint; badge ordering (#150)
- ci: use dump_packages.py callback to get packages used by role (#152)
- test: support for qdevice tls and kaptb options (#153)
- ci: tox-lsr version 3.1.1 (#156)

[1.10.1] - 2023-09-08
--------------------

### Other Changes

- docs: fix missing pronoun in readme (#141)

- ci: Add markdownlint, test_html_build, and build_docs workflows (#142)

  - markdownlint runs against README.md to avoid any issues with
    converting it to HTML
  - test_converting_readme converts README.md > HTML and uploads this test
    artifact to ensure that conversion works fine
  - build_docs converts README.md > HTML and pushes the result to the
    docs branch to publish dosc to GitHub pages site.
  - Fix markdown issues in README.md
  
  Signed-off-by: Sergei Petrosian <spetrosi@redhat.com>

- docs: Make badges consistent, run markdownlint on all .md files (#143)

  - Consistently generate badges for GH workflows in README RHELPLAN-146921
  - Run markdownlint on all .md files
  - Add custom-woke-action if not used already
  - Rename woke action to Woke for a pretty badge
  
  Signed-off-by: Sergei Petrosian <spetrosi@redhat.com>

- ci: Remove badges from README.md prior to converting to HTML (#144)

  - Remove thematic break after badges
  - Remove badges from README.md prior to converting to HTML
  
  Signed-off-by: Sergei Petrosian <spetrosi@redhat.com>

[1.10.0] - 2023-07-19
--------------------

### New Features

- feat: cluster and quorum can have distinct passwords (#134)

### Bug Fixes

- fix: various minor fixes (#137)
- fix: facts being gathered unnecessarily (#139)

### Other Changes

- ci: Add pull request template and run commitlint on PR title only (#133)
- ci: Rename commitlint to PR title Lint, echo PR titles from env var (#135)
- ci: test with pcs v0.11.6 (#136)
- ci: ansible-lint - ignore var-naming[no-role-prefix] (#138)

[1.9.3] - 2023-05-26
--------------------

### Other Changes

- style: address ansible-lint issues
- docs: Consistent contributing.md for all roles - allow role specific contributing.md section
- docs: fix collection requirements section
- style: fix linter issues in SBD task files
- test: update for upcoming pcs release
- refactor: update qdevice for upcoming pcs release

[1.9.2] - 2023-04-27
--------------------

### Other Changes

- test: check generated files for ansible_managed, fingerprint
- ci: Add commitlint GitHub action to ensure conventional commits with feedback

[1.9.1] - 2023-04-13
--------------------

### Other Changes

- fix ansible-lint issues with changed_when, others (#118)

[1.9.0] - 2023-04-06
--------------------

### New Features

- add support for resource and operation defaults
- Add possibility to load SBD watchdog kernel modules (#82)

### Bug Fixes

- use pcs to setup qdevice certificates if available

### Other Changes

- Add README-ansible.md to refer Ansible intro page on linux-system-roles.github.io (#115)
- Fingerprint RHEL System Role managed config files (#116)

[1.8.7] - 2023-02-08
--------------------

### New Features

- none

### Bug Fixes

- Fix stonith watchdog timeout; fix purging nodes from pacemaker (#105)

### Other Changes

- none

[1.8.6] - 2023-02-02
--------------------

### New Features

- none

### Bug Fixes

- Fence agent firewall port is restricted to x86_64 architecture. (#106)

### Other Changes

- none

[1.8.5] - 2023-01-13
--------------------

### New Features

- none

### Bug Fixes

- Not request password to be specified when purging cluster (#92)

When running the role with ha_cluster_cluster_present: false to purge
cluster passwords are not required
Add a missing bool mapping
do not set hacluster password when it is empty

### Other Changes

- ansible-lint 6.x fixes (#94)
- Add check for non-inclusive language (#97)

[1.8.4] - 2022-12-13
--------------------

### New Features

- none

### Bug Fixes

- Allow enabled SBD on disabled cluster (#81)

Currently the sbd.service will not be enabled if the cluster autostart
is disabled. This is not intended behavior as is will effectively break
the feature. We can simply remove the condition to depend on
ha_cluster_start_on_boot as on a RHEL8 system the sbd.service has a
dependencies (Before/After/PartOf/RequiredBy) to cluster related
services which make sure it is only ever started by the cluster (a
manual start is not possible).

### Other Changes

- none

[1.8.3] - 2022-12-12
--------------------

### New Features

- none

### Bug Fixes

- command warn is not supported in ansible-core 2.14

If users want to suppress the warning, users will need to configure
ansible.cfg.

- fix ownership of cib.xml

- update for upcoming pcs release

The upcoming pcs brings stricter validation for resource
configuration to prevent certain types of misconfiguration.

- tests: add qnetd cleanup

### Other Changes

- none

[1.8.2] - 2022-11-30
--------------------

### New Features

- none

### Bug Fixes

- fix qnetd check mode

### Other Changes

- none

[1.8.1] - 2022-11-14
--------------------

### New Features

- none

### Bug Fixes

- none

### Other Changes

- long heading causes problems with md to adoc conversion

The long heading causes problems with md to adoc conversion.  Shorten
the length by using abbreviations.

[1.8.0] - 2022-11-01
--------------------

### New Features

- Use the firewall role and the selinux role from the ha_cluster role

- Introduce ha_cluster_manage_firewall to use the firewall role to
  manage the high-availability service and the fence-virt port.
  Default to false - means the firewall role is not used.

- Introduce ha_cluster_manage_selinux to use the selinux role to
  manage the ports in the high-availability service.
  Assign cluster_port_t to the high-availability service ports.
  Default to false - means the selinux role is not used.

- Add the test check task tasks/check_firewall_selinux.yml for
  verify the ports status.

Note: This pr changes the ha_cluster role's behavior slightly.
It used to configure firewall without any settings if the firewall
service is enabled. With this change made by this pr, unless
ha_cluster_manage_firewall is set to true, the firewall is not
configured.

- Use the certificate role to create the cert and the key

- Introduce a variable ha_cluster_pcsd_certificates to set the certificate_requests.

Note: Get mode of /var/lib/pcsd using the stat module and reset it
in the following file for fixing the issue "risky-file-permissions
File permissions unset or incorrect".

- add support for configuring qnetd

- add support for configuring qdevice

- qdevice and qnetd documentation

### Bug Fixes

- fix decoding variables from an Ansible vault

Workaround Ansible issue https://github.com/ansible/ansible/issues/24425
Before fix, the role was failing with the following message:
object of type 'AnsibleVaultEncryptedUnicode' has no len()

- add a test for vault-encrypted variables

- adapt tests with vault-encrypted variables for CI

- use a real temporary directory for test secrets

The tests were writing generated secrets to the directory tests/tmp
which is shared by all tests when running tests in parallel.
Instead, create a real temporary directory for these secrets for the
tests that use generated secrets.

- fix checking hacluster password

- update sbd config file template

- fix installing qnetd and pcs packages

- fix auth for qnetd host

### Other Changes

- fix linter issues

- fix qnetd setup in tests

- fix typos

[1.7.5] - 2022-09-19
--------------------

### New Features

- none

### Bug Fixes

- only install and setup fence-virt on x86_64 hosts (#64)

fence-virt is not available for any architecture other than x86_64

### Other Changes

- replace yes, no, default with true, false, d

Use `true`, `false`, and `d` instead of `yes`, `no`, and `default`

- readme: update SBD example (#61)

[1.7.4] - 2022-07-19
--------------------

### New Features

- none

### Bug Fixes

- readme: describe limitations of udp transports (#56)

### Other Changes

- make all tests work with gather_facts: false (#52)

Ensure tests work when using ANSIBLE_GATHERING=explicit

- make min_ansible_version a string in meta/main.yml (#53)

The Ansible developers say that `min_ansible_version` in meta/main.yml
must be a `string` value like `"2.9"`, not a `float` value like `2.9`.

- Add CHANGELOG.md (#54)

[1.7.3] - 2022-06-10
--------------------

### New Features

- none

### Bug fixes

- s/ansible\_play\_hosts\_all/ansible\_play\_hosts/ where applicable

### Other Changes

- none

[1.7.2] - 2022-05-27
--------------------

### New Features

- none

### Bug fixes

- If ansible\_hostname includes '\_' the role fails with `invalid characters in salt`

### Other Changes

- Setup test vars

[1.7.1] - 2022-05-06
--------------------

### New Features

- none

### Bug Fixes

- additional fix for password\_hash salt length

### Other Changes

- bump tox-lsr version to 2.11.0; remove py37; add py310

[1.7.0] - 2022-04-13
--------------------

### New features

- Add support for SBD devices
- support gather\_facts: false; support setup-snapshot.yml
- add support for configuring bundle resources

### Bug fixes

- Pcs fixes

### Other Changes

- none

[1.6.0] - 2022-03-15
--------------------

### New features

- add support for advanced corosync configuration

### Bug Fixes

- none

### Other Changes

- bump tox-lsr version to 2.10.1

[1.5.0] - 2022-02-17
--------------------

### New features

- add SBD support

### Bug Fixes

- none

### Other Changes

- bump tox-lsr version to 2.9.1

[1.4.1] - 2022-02-01
--------------------

### New Features

- none

### Bug fixes

- fix default pcsd permissions

### Other Changes

- none

[1.4.0] - 2022-01-10
--------------------

### New features

- add support for configuring resource constraints

### Bug Fixes

- none

### Other Changes

- bump tox-lsr version to 2.8.3
- change recursive role symlink to individual role dir symlinks

[1.3.2] - 2021-11-08
--------------------

### New Features

- none

### Bug Fixes

- fix ansible-lint issues

### Other Changes

- update tox-lsr version to 2.7.1
- support python 39, ansible-core 2.12, ansible-plugin-scan

[1.3.1] - 2021-09-22
--------------------

### New features

- use firewall-cmd instead of firewalld module
- replace rhsm\_repository with subscription-manager cli
- Use the openssl command-line interface instead of the openssl module

### Bug fixes

- fix password\_hash salt length

### Other Changes

- use apt-get install -y
- use tox-lsr version 2.5.1

[1.3.0] - 2021-08-10
--------------------

### New features

- Drop support for Ansible 2.8 by bumping the Ansible version to 2.9

### Bug Fixes

- none

### Other Changes

- none

[1.2.0] - 2021-07-13
--------------------

### New features

- add pacemaker cluster properties configuration

### Bug fixes

- do not fail if openssl is not installed

### Other Changes

- none

[1.1.1] - 2021-05-27
--------------------

### New Features

- none

### Bug Fixes

- none

### Other Changes

- Code cleanup

[1.1.0] - 2021-05-20
--------------------

### New features

- add pacemaker resources configuration

### Bug Fixes

- fix reading preshared keys
- Fix issues related to enabling repositories
- Ha\_cluster - fixing ansible-test errors

### Other Changes

- Remove python-26 environment from tox testing
- update to tox-lsr 2.4.0 - add support for ansible-test with docker
- CI: Add support for RHEL-9

[1.0.0] - 2021-02-17
--------------------

### Initial Release
